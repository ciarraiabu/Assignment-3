<!DOCTYPE HTML>
<html>
<head>
  <link rel="stylesheet" href="styles.css">
</body>
</html>

    </head>

<body>
    <h1>Create</h1><br>
    <form method="post">
        ID: <input type="text" name="id"><br>
        Author: <input type="text" name="creator"><br>
        Title: <input type="text" name="title"><br>
        Genre: <input type="text" name="type"><br>
        Identifier:<input type="text" name="ISBN"><br>
        Date: <input type="text" name="date"><br>
        Language: <input type="text" name="lang"><br>
        Description:<input type="text" name="desc"><br>
        <input type="submit" value="submit" name="submit">
</form>
    
<?php
        function C(){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "Assignment3_database";
            // Create connection
            $conn = mysqli_connect($servername, $username, $password, $dbname);
            // Check connection
            if (!$conn) {
                die("Connection failed: " . mysqli_connect_error());
            }
            $id = $_POST['id'];
            $auth = $_POST['creator'];
            $title = $_POST['title'];
            $gen = $_POST['type'];
            $ident = $_POST['ISBN'];
            $dat = $_POST['date'];
            $lang = $_POST['lang'];
            $desc = $_POST['desc'];
            
            $sql = "INSERT INTO eBook_MetaData (id, creator, title, type, identifier, date, language, description)
            VALUES ('$id', '$auth', '$title', '$gen', '$ident', '$dat', '$lang', '$desc')";
            if (mysqli_query($conn, $sql)) {
                echo "New record created successfully";
            } else {
                echo "Error: " . $sql . "<br>" . mysqli_error($conn);
            }
            mysqli_close($conn);
        }
        if (isset($_POST['submit'])) {
            C();
        
        }
    ?>
    
    <h1>Retrieve</h1><br>
    <?php
        function R(){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "Assignment3_database";
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            //$sql = "SELECT * FROM stock";
            $sql = "SELECT * FROM eBook_MetaData";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                echo "<table id = 'myTable'>
                <tr>
                <th>ID</th>
                <th>creator</th>
                <th>title</th>
                <th>type</th>
                <th>identifier</th>
                <th>date</th>
                <th>language</th>
                <th>description</th>
                </tr>";
                // output data of each row
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                    <td>".$row["id"]."</td>
                    <td>".$row["creator"]."</td>
                    <td>".$row["title"]."</td>
                    <td>".$row["type"]."</td>
                    <td>".$row["identifier"]."</td>
                    <td>".$row["date"]."</td>
                    <td>".$row["language"]."</td>
                    <td>".$row["description"]."</td>
                    </tr>";
                }
                echo "</table>";
            } else {
                echo "0 results";
            }
            $conn->close();
        }
        R();
    ?>
  <h1>Update</h1><br>
    <form method="post">
        Name of column: <input type="text" name="title"><br>
        replace value with: <input type="text" name="rep"><br>
        row id: <input type="text" name="id"><br>
        <input type="submit" value="submit" name="submit3">
    </form>

    <?php
        function U(){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "Assignment3_database";
            $rep = $_POST['rep'];
            //$nam= $_POST['name'];
            $id = $_POST['id'];
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
	    //echo "rep1111=$rep";
            //echo "secret1111=$auth";
            $sql = "UPDATE eBook_MetaData SET title='$rep' WHERE id=$id";
            /*}*/
            if ($conn->query($sql) === TRUE) {
                echo "Record updated successfully";
            } else {
                echo "Error updating record: " . $conn->error;
            }
            $conn->close();
        }
        if (isset($_POST['submit3'])) {
            U();
            echo "<br>your new table:<br>";
            R();
        }
    ?>
    
<h1>Delete</h1><br>
    <form method="post">
        ID: <input type="text" name="id"><br>
        <input type="submit" value="Delete" name="submit2">
    </form>

    <?php
        function D(){
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "Assignment3_database";
            // Create connection
            $conn = new mysqli($servername, $username, $password, $dbname);
            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }
            $id=$_POST['id'];
            // sql to delete a record
            $sql = "DELETE FROM eBook_MetaData WHERE id=$id";
            if ($conn->query($sql) === TRUE) {
                echo "Record deleted successfully";
            } else {
                echo "Error deleting record: " . $conn->error;
            }
            $conn->close();
        }
        if (isset($_POST['submit2'])) {
            D();
            echo "<br>your new table:<br>";
            R();
        }
    ?>


