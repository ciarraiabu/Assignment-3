<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Assignment3_database";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// sql to create table
$sql = "CREATE TABLE `eBook_MetaData` (
  `id` int(11) NOT NULL,
  `creator` char(120) NOT NULL,
  `title` char(120) NOT NULL,
  `type` varchar(200) NOT NULL,
  `identifier` varchar(250) NOT NULL,
  `date` date NOT NULL,
  `language` char(120) NOT NULL,
  `description` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
";

if ($conn->query($sql) === TRUE) {
    echo "Table eBook_MetaData created successfully";
} else {
    echo "Error creating table: " . $conn->error;
}

$conn->close();
?> 
